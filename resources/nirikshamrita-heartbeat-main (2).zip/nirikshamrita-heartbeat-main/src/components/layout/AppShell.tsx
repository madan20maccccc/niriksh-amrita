import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ComponentType } from "react";
import { Bell, ChevronLeft, LogOut, Menu, Search, User } from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { clearSession, getSession, type Role } from "@/lib/auth";
import { cn } from "@/lib/utils";

export interface NavItem {
  to: string;
  label: string;
  icon: ComponentType<{ className?: string }>;
}

export function AppShell({
  role,
  nav,
  title,
}: {
  role: Role;
  nav: NavItem[];
  title: string;
}) {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: s => s.location.pathname });
  const [session, setS] = useState<ReturnType<typeof getSession>>(null);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const s = getSession();
    if (!s || s.role !== role) {
      navigate({ to: role === "admin" ? "/login/admin" : "/login/nurse" });
      return;
    }
    setS(s);
  }, [role, navigate]);

  const onLogout = () => {
    clearSession();
    navigate({ to: "/welcome" });
  };

  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-72 -translate-x-full border-r border-border bg-sidebar transition-transform lg:static lg:translate-x-0",
          open && "translate-x-0",
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-5">
          <Link to="/welcome" className="flex items-center gap-2">
            <Logo size={32} withWordmark tone="compact" />
          </Link>
          <button className="lg:hidden" onClick={() => setOpen(false)}>
            <ChevronLeft className="h-5 w-5" />
          </button>
        </div>
        <div className="px-3 py-2">
          <div className="px-3 py-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            {role === "admin" ? "Hospital Admin" : "Nurse Workspace"}
          </div>
          <nav className="space-y-1">
            {nav.map(item => {
              const active = pathname === item.to || (item.to !== `/${role}` && pathname.startsWith(item.to));
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition",
                    active
                      ? "bg-primary-soft text-primary"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-primary",
                  )}
                >
                  <item.icon className={cn("h-4 w-4", active ? "text-primary" : "text-muted-foreground group-hover:text-primary")} />
                  <span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="absolute inset-x-3 bottom-4">
          <button
            onClick={onLogout}
            className="flex w-full items-center gap-3 rounded-xl border border-sidebar-border bg-white px-3 py-2.5 text-sm text-foreground transition hover:bg-muted"
          >
            <LogOut className="h-4 w-4 text-muted-foreground" /> Sign out
          </button>
        </div>
      </aside>
      {open && <div className="fixed inset-0 z-30 bg-black/30 lg:hidden" onClick={() => setOpen(false)} />}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 border-b border-border bg-background/85 backdrop-blur">
          <div className="flex h-16 items-center gap-4 px-4 sm:px-6">
            <button className="lg:hidden" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button>
            <div className="min-w-0">
              <div className="text-[11px] uppercase tracking-wider text-muted-foreground">NirikshAmrita</div>
              <h1 className="truncate font-display text-lg text-foreground">{title}</h1>
            </div>
            <div className="ml-auto flex items-center gap-3">
              <div className="hidden items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm md:flex">
                <Search className="h-4 w-4 text-muted-foreground" />
                <input placeholder="Search patients, wards, nurses…" className="w-56 bg-transparent outline-none" />
              </div>
              <button className="relative grid h-10 w-10 place-items-center rounded-xl border border-border bg-white">
                <Bell className="h-4 w-4" />
                <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[var(--color-critical)]" />
              </button>
              <div className="hidden items-center gap-3 rounded-xl border border-border bg-white px-3 py-1.5 md:flex">
                <div className="grid h-8 w-8 place-items-center rounded-full bg-primary-soft text-primary">
                  <User className="h-4 w-4" />
                </div>
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-foreground">{session?.name ?? "—"}</div>
                  <div className="truncate text-[11px] text-muted-foreground">
                    {role === "admin" ? "Administrator" : `${session?.ward} · ${session?.shift}`}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}