import logo from "@/assets/logo.png.asset.json";
import { cn } from "@/lib/utils";

interface LogoProps {
  size?: number;
  withWordmark?: boolean;
  className?: string;
  tone?: "default" | "compact";
}

export function Logo({ size = 44, withWordmark = false, className, tone = "default" }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <img
        src={logo.url}
        alt="NirikshAmrita logo"
        width={size}
        height={size}
        className="object-contain"
        style={{ width: size, height: size }}
      />
      {withWordmark && (
        <div className="leading-tight">
          <div
            className={cn(
              "font-display font-semibold text-primary",
              tone === "compact" ? "text-lg" : "text-xl",
            )}
          >
            NirikshAmrita
          </div>
          {tone !== "compact" && (
            <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              Amrita Hospital
            </div>
          )}
        </div>
      )}
    </div>
  );
}