import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AlertTriangle, Filter } from "lucide-react";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill, severityTone } from "@/components/ui/status-pill";
import { alerts } from "@/data/hospital";

export const Route = createFileRoute("/admin/alerts")({ component: AlertsPage });

function AlertsPage() {
  const [sev, setSev] = useState<"All" | "Red" | "Orange" | "Yellow">("All");
  const list = alerts.filter(a => sev === "All" || a.severity === sev);
  const counts = {
    Red: alerts.filter(a => a.severity === "Red").length,
    Orange: alerts.filter(a => a.severity === "Orange").length,
    Yellow: alerts.filter(a => a.severity === "Yellow").length,
  };
  return (
    <div className="space-y-6">
      <SectionHeader title="Alerts" hint="All clinical alerts across the hospital" />
      <div className="grid grid-cols-3 gap-4">
        <Tile label="Red · Critical" value={counts.Red} tone="critical" />
        <Tile label="Orange · High" value={counts.Orange} tone="warning" />
        <Tile label="Yellow · Monitor" value={counts.Yellow} tone="info" />
      </div>
      <Card className="p-4">
        <div className="flex items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <select value={sev} onChange={e => setSev(e.target.value as never)} className="bg-transparent outline-none">
            <option>All</option><option>Red</option><option>Orange</option><option>Yellow</option>
          </select>
        </div>
      </Card>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-5 py-3 text-left">Severity</th>
              <th className="px-5 py-3 text-left">Patient</th>
              <th className="px-5 py-3 text-left">Ward / Bed</th>
              <th className="px-5 py-3 text-left">Reason</th>
              <th className="px-5 py-3 text-left">Time</th>
              <th className="px-5 py-3 text-left">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {list.map(a => (
              <tr key={a.id} className="hover:bg-primary-soft/30">
                <td className="px-5 py-3"><StatusPill tone={severityTone(a.severity)}>{a.severity}</StatusPill></td>
                <td className="px-5 py-3 font-medium text-foreground">{a.patientName}</td>
                <td className="px-5 py-3">{a.ward} · {a.bed}</td>
                <td className="px-5 py-3">{a.reason}</td>
                <td className="px-5 py-3 text-muted-foreground">{a.time}</td>
                <td className="px-5 py-3"><StatusPill tone={a.status === "Active" ? "critical" : a.status === "Acknowledged" ? "warning" : "success"}>{a.status}</StatusPill></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function Tile({ label, value, tone }: { label: string; value: number; tone: "critical"|"warning"|"info" }) {
  const bg = tone === "critical" ? "from-[color-mix(in_oklab,var(--color-critical)_8%,transparent)]"
    : tone === "warning" ? "from-[color-mix(in_oklab,var(--color-warning)_8%,transparent)]"
    : "from-[color-mix(in_oklab,var(--color-info)_8%,transparent)]";
  return (
    <div className={"rounded-2xl border border-border bg-gradient-to-br to-white p-5 shadow-card " + bg}>
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="mt-2 font-display text-3xl text-foreground">{value}</div>
    </div>
  );
}