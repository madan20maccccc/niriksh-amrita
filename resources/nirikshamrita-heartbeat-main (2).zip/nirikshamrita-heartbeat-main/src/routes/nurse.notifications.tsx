import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, BellRing, Clock, TrendingUp } from "lucide-react";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill } from "@/components/ui/status-pill";
import { alerts } from "@/data/hospital";

export const Route = createFileRoute("/nurse/notifications")({ component: NotifPage });

function NotifPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Notifications" hint="Critical alerts, reminders and escalations" />
      <div className="grid gap-4 sm:grid-cols-4">
        <Tile icon={AlertTriangle} label="Critical alerts" v={alerts.filter(a=>a.severity==="Red").length} tone="critical" />
        <Tile icon={Clock} label="Missing vitals" v={5} tone="warning" />
        <Tile icon={BellRing} label="Reminders" v={3} tone="info" />
        <Tile icon={TrendingUp} label="Escalations" v={2} tone="primary" />
      </div>
      <Card className="p-4">
        <ul className="divide-y divide-border">
          {alerts.slice(0, 10).map(a => (
            <li key={a.id} className="flex items-center justify-between py-3">
              <div>
                <div className="text-sm font-medium text-foreground">{a.reason}</div>
                <div className="text-xs text-muted-foreground">{a.patientName} · Bed {a.bed} · {a.time}</div>
              </div>
              <StatusPill tone={a.severity === "Red" ? "critical" : a.severity === "Orange" ? "warning" : "info"}>{a.severity}</StatusPill>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}

function Tile({ icon: Icon, label, v, tone }: { icon: React.ComponentType<{ className?: string }>; label: string; v: number; tone: "critical"|"warning"|"info"|"primary" }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
      <div className="flex items-center justify-between">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="mt-2 font-display text-3xl text-foreground">{v}</div>
      <div className="mt-2"><StatusPill tone={tone}>{tone}</StatusPill></div>
    </div>
  );
}