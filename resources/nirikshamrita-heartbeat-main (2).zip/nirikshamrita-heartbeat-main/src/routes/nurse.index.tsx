import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, ClipboardList, Sparkles } from "lucide-react";
import { Card, SectionHeader, Stat } from "@/components/ui/section";
import { StatusPill, riskTone } from "@/components/ui/status-pill";
import { getSession } from "@/lib/auth";
import { nurses, patientsForNurse } from "@/data/hospital";

export const Route = createFileRoute("/nurse/")({ component: NurseHome });

function NurseHome() {
  const [name, setName] = useState("Nurse");
  const [ward, setWard] = useState("Ward");
  const [shift, setShift] = useState("Morning");
  const [nurseId, setNurseId] = useState(nurses[0].id);

  useEffect(() => {
    const s = getSession();
    if (s) {
      setName(s.name);
      setWard(s.ward ?? "Ward");
      setShift(s.shift ?? "Morning");
      const n = nurses.find(n => n.email === s.email) ?? nurses[0];
      setNurseId(n.id);
    }
  }, []);

  const myPatients = patientsForNurse(nurseId);
  const critical = myPatients.filter(p => p.risk === "Critical").length;
  const greeting = new Date().getHours() < 12 ? "Good morning" : new Date().getHours() < 17 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-gradient-to-r from-white to-primary-soft/50 p-5 shadow-card">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{greeting}</div>
            <h2 className="font-display text-2xl text-foreground">{name}</h2>
            <div className="mt-1 text-sm text-muted-foreground">{ward} · {shift} shift</div>
          </div>
          <div className="flex items-center gap-2">
            <StatusPill tone="primary">Shift in progress</StatusPill>
            <Link to="/nurse/patients" className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant">View patients</Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        <Stat label="My patients" value={myPatients.length} tone="primary" />
        <Stat label="Pending vitals" value={Math.max(3, Math.floor(myPatients.length/3))} tone="warning" />
        <Stat label="Critical alerts" value={critical} tone="critical" />
        <Stat label="Today's tasks" value={6} />
        <Stat label="Shift progress" value="62%" hint="of 12 hr shift" tone="info" />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Card className="p-5">
          <SectionHeader title="Today's Tasks"
            action={<Link to="/nurse/tasks" className="text-sm font-medium text-primary hover:underline">View all</Link>} />
          <ul className="space-y-3">
            {[
              { t: "Morning vitals · 12 patients", s: "In progress", icon: Activity, tone: "warning" as const },
              { t: "Medication round · 09:00", s: "Pending", icon: ClipboardList, tone: "info" as const },
              { t: "SBAR handover prep · ICU Bay 3", s: "Pending", icon: Sparkles, tone: "primary" as const },
              { t: "Pending reviews · 4 patients", s: "Pending", icon: AlertTriangle, tone: "critical" as const },
              { t: "Hand hygiene audit", s: "Done", icon: CheckCircle2, tone: "success" as const },
            ].map((it, i) => (
              <li key={i} className="flex items-center justify-between rounded-xl border border-border bg-white p-3">
                <div className="flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary-soft text-primary"><it.icon className="h-4 w-4" /></span>
                  <div className="text-sm font-medium text-foreground">{it.t}</div>
                </div>
                <StatusPill tone={it.tone}>{it.s}</StatusPill>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-5">
          <SectionHeader title="High-priority patients" />
          <ul className="space-y-3">
            {myPatients.filter(p => p.risk === "Critical" || p.risk === "High").slice(0, 5).map(p => (
              <li key={p.id}>
                <Link to={`/nurse/patient/${p.id}` as never} className="flex items-center justify-between rounded-xl border border-border bg-white p-3 hover:border-primary/30">
                  <div>
                    <div className="text-sm font-medium text-foreground">{p.name}</div>
                    <div className="text-xs text-muted-foreground">Bed {p.bed} · {p.diagnosis}</div>
                  </div>
                  <StatusPill tone={riskTone(p.risk)}>{p.risk}</StatusPill>
                </Link>
              </li>
            ))}
            {myPatients.filter(p => p.risk === "Critical" || p.risk === "High").length === 0 && (
              <div className="rounded-xl border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
                No high-priority patients right now.
              </div>
            )}
          </ul>
        </Card>
      </div>
    </div>
  );
}