import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Card, SectionHeader } from "@/components/ui/section";
import { getSession } from "@/lib/auth";
import { nurses, patientsForNurse } from "@/data/hospital";

export const Route = createFileRoute("/nurse/sbar/")({ component: SbarIndex });

function SbarIndex() {
  const [nurseId, setNurseId] = useState(nurses[0].id);
  useEffect(() => {
    const s = getSession();
    const n = nurses.find(n => n.email === s?.email) ?? nurses[0];
    setNurseId(n.id);
  }, []);
  const list = patientsForNurse(nurseId);
  return (
    <div className="space-y-6">
      <SectionHeader title="SBAR Handover" hint="Pick a patient to generate a structured handover note" />
      <Card className="p-4">
        <ul className="divide-y divide-border">
          {list.map(p => (
            <li key={p.id}>
              <Link to={`/nurse/sbar/${p.id}` as never} className="flex items-center justify-between rounded-lg p-3 hover:bg-primary-soft/30">
                <div>
                  <div className="text-sm font-medium text-foreground">{p.name}</div>
                  <div className="text-xs text-muted-foreground">Bed {p.bed} · {p.diagnosis}</div>
                </div>
                <span className="text-sm text-primary">Prepare SBAR →</span>
              </Link>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}