import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill, riskTone } from "@/components/ui/status-pill";
import { buildTrend, patientById, alerts as allAlerts } from "@/data/hospital";

export const Route = createFileRoute("/nurse/patient/$patientId")({ component: PatientDetail });

function PatientDetail() {
  const { patientId } = useParams({ from: "/nurse/patient/$patientId" });
  const p = patientById(patientId);
  if (!p) return <div className="text-sm text-muted-foreground">Patient not found.</div>;

  const trendBP = buildTrend(1, 120, 18);
  const trendHR = buildTrend(2, 84, 14);
  const trendSpO2 = buildTrend(3, 95, 4);
  const trendSugar = buildTrend(4, 140, 30);
  const trendTemp = buildTrend(5, 98, 2);
  const trendRR = buildTrend(6, 18, 4);

  const alerts = allAlerts.filter(a => a.patientId === p.id);

  return (
    <div className="space-y-6">
      <Link to="/nurse/patients" className="text-sm text-primary hover:underline">← Back to my patients</Link>

      <Card className="p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-primary-soft text-2xl font-medium text-primary">{p.name[0]}</div>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">{p.id}</div>
              <h2 className="font-display text-2xl text-foreground">{p.name}</h2>
              <div className="mt-1 text-sm text-muted-foreground">{p.age} · {p.gender === "M" ? "Male" : "Female"} · {p.diagnosis}</div>
              <div className="mt-1 text-xs text-muted-foreground">{p.ward} · Bed {p.bed} · {p.doctor}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <StatusPill tone={riskTone(p.risk)}>{p.risk} risk</StatusPill>
            <Link to={`/nurse/vitals/${p.id}` as never} className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant">Enter vitals</Link>
            <Link to={`/nurse/sbar/${p.id}` as never} className="rounded-xl border border-border bg-white px-4 py-2.5 text-sm">SBAR handover</Link>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {[
          ["BP", p.vitals.bp],
          ["HR", `${p.vitals.hr} bpm`],
          ["SpO₂", `${p.vitals.spo2}%`],
          ["Temp", `${p.vitals.temp}°F`],
          ["Sugar", `${p.vitals.sugar} mg/dL`],
          ["RR", `${p.vitals.rr}/min`],
          ["Pain", `${p.vitals.pain}/10`],
          ["Urine", `${p.vitals.urine} ml`],
          ["Consciousness", p.vitals.consciousness],
        ].map(([l, v]) => (
          <div key={l as string} className="rounded-2xl border border-border bg-card p-4 shadow-card">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{l}</div>
            <div className="mt-1 font-display text-xl text-foreground">{v as string}</div>
          </div>
        ))}
      </div>

      <Card className="overflow-hidden p-0">
        <div className="gradient-primary p-5 text-primary-foreground">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em]"><Sparkles className="h-3.5 w-3.5" /> NirikshAmrita AI Summary</div>
          <p className="mt-3 font-display text-lg leading-snug">{p.aiSummary}</p>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <TrendCard title="Blood Pressure (systolic)" data={trendBP} />
        <TrendCard title="Heart Rate" data={trendHR} />
        <TrendCard title="SpO₂" data={trendSpO2} />
        <TrendCard title="Sugar" data={trendSugar} />
        <TrendCard title="Temperature" data={trendTemp} />
        <TrendCard title="Respiratory Rate" data={trendRR} />
      </div>

      <Card className="p-5">
        <SectionHeader title="Alert History" hint="Timeline of clinical events" />
        {alerts.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-4 text-center text-sm text-muted-foreground">No alerts recorded.</div>
        ) : (
          <ol className="relative space-y-4 border-l border-border pl-5">
            {alerts.map(a => (
              <li key={a.id} className="relative">
                <span className="absolute -left-[27px] top-1 grid h-3 w-3 rounded-full bg-primary ring-4 ring-primary-soft" />
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium text-foreground">{a.reason}</div>
                    <div className="text-xs text-muted-foreground">{a.time} · {a.ward} · Bed {a.bed}</div>
                  </div>
                  <StatusPill tone={a.status === "Active" ? "critical" : a.status === "Acknowledged" ? "warning" : "success"}>{a.status}</StatusPill>
                </div>
              </li>
            ))}
          </ol>
        )}
      </Card>
    </div>
  );
}

function TrendCard({ title, data }: { title: string; data: { day: string; morning: number; evening: number; night: number }[] }) {
  return (
    <Card className="p-5">
      <SectionHeader title={title} hint="14-day morning / evening / night" />
      <div className="h-52">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
            <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
            <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
            <Line type="monotone" dataKey="morning" stroke="var(--color-primary)" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="evening" stroke="var(--color-info)" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="night" stroke="var(--color-warning)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}