import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Activity, AlertTriangle, BedDouble, Hospital, Plus, Sparkles, UserCog, Users,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Line, LineChart,
} from "recharts";
import { Card, SectionHeader, Stat } from "@/components/ui/section";
import { StatusPill } from "@/components/ui/status-pill";
import {
  admissionsTrend, aiInsight, alerts, alertTrend, hospitalSummary, nurses, patients, wards,
} from "@/data/hospital";

export const Route = createFileRoute("/admin/")({
  component: AdminDashboard,
});

function AdminDashboard() {
  const critical = alerts.filter(a => a.severity === "Red").length;
  const pending = alerts.filter(a => a.status !== "Resolved").length;
  const occupied = wards.reduce((s, w) => s + w.occupied, 0);
  const totalBeds = wards.reduce((s, w) => s + w.beds, 0);

  return (
    <div className="space-y-6">
      {/* Status banner */}
      <div className="rounded-2xl border border-border bg-gradient-to-r from-white to-primary-soft/50 p-5 shadow-card">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary-soft text-primary">
              <Hospital className="h-5 w-5" />
            </span>
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Amrita Hospital · Status</div>
              <div className="font-display text-lg text-foreground">
                Operational across {wards.length} wards
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <StatusPill tone="success">Operational</StatusPill>
            <div className="text-right text-xs text-muted-foreground">
              <div>Last updated</div>
              <div className="font-medium text-foreground">{new Date().toLocaleString()}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
        <Stat label="Total patients" value={patients.length} hint="across 8 wards" tone="primary" />
        <Stat label="Total nurses" value={nurses.length} hint="active roster" />
        <Stat label="Total wards" value={wards.length} />
        <Stat label="Critical alerts" value={critical} hint="last 24h" tone="critical" />
        <Stat label="Pending alerts" value={pending} tone="warning" />
        <Stat label="Beds occupied" value={`${occupied}/${totalBeds}`} hint={`${Math.round(occupied/totalBeds*100)}% occupancy`} tone="info" />
      </div>

      {/* Ward risk + AI insight */}
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Card className="p-5">
          <SectionHeader title="Live Ward Risk Overview" hint="Updated every 60 seconds" />
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {wards.map(w => {
              const tone = w.riskScore >= 70 ? "critical" : w.riskScore >= 50 ? "warning" : w.riskScore >= 35 ? "info" : "success";
              return (
                <div key={w.id} className="rounded-xl border border-border bg-background/60 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs uppercase tracking-wider text-muted-foreground">{w.id}</div>
                      <div className="font-display text-base text-foreground">{w.name}</div>
                    </div>
                    <StatusPill tone={tone}>{w.status}</StatusPill>
                  </div>
                  <div className="mt-3 text-xs text-muted-foreground">
                    {w.patients} patients · {w.nurses} nurses
                  </div>
                  <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full gradient-primary" style={{ width: `${w.riskScore}%` }} />
                  </div>
                  <div className="mt-1 text-[11px] text-muted-foreground">Risk index {w.riskScore}</div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="overflow-hidden p-0">
          <div className="gradient-primary p-5 text-primary-foreground">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em]">
              <Sparkles className="h-3.5 w-3.5" /> NirikshAmrita AI · Hospital Insight
            </div>
            <p className="mt-3 font-display text-lg leading-snug">
              {aiInsight}
            </p>
          </div>
          <div className="grid grid-cols-3 divide-x divide-border">
            {[
              { l: "Vitals completed", v: hospitalSummary.vitalsCompleted },
              { l: "Admissions", v: hospitalSummary.admissions },
              { l: "Discharges", v: hospitalSummary.discharges },
            ].map(s => (
              <div key={s.l} className="p-4 text-center">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{s.l}</div>
                <div className="mt-1 font-display text-xl text-foreground">{s.v}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Critical events + Quick actions */}
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Card className="p-5">
          <SectionHeader title="Recent Critical Events" hint="Live escalation feed"
            action={<Link to="/admin/alerts" className="text-sm font-medium text-primary hover:underline">View all</Link>} />
          <div className="divide-y divide-border">
            {alerts.slice(0, 6).map(a => (
              <div key={a.id} className="grid grid-cols-[auto_1fr_auto] items-center gap-4 py-3">
                <span className={"grid h-9 w-9 place-items-center rounded-xl " +
                  (a.severity === "Red" ? "bg-[color-mix(in_oklab,var(--color-critical)_15%,transparent)] text-[var(--color-critical)]"
                    : a.severity === "Orange" ? "bg-[color-mix(in_oklab,var(--color-warning)_15%,transparent)] text-[var(--color-warning)]"
                    : "bg-[color-mix(in_oklab,var(--color-info)_15%,transparent)] text-[var(--color-info)]")}>
                  <AlertTriangle className="h-4 w-4" />
                </span>
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-foreground">{a.reason}</div>
                  <div className="text-xs text-muted-foreground">
                    {a.ward} · Bed {a.bed} · {a.patientName}
                  </div>
                </div>
                <div className="text-right text-xs text-muted-foreground">
                  <div>{a.time}</div>
                  <div className="mt-1"><StatusPill tone={a.status === "Active" ? "critical" : a.status === "Acknowledged" ? "warning" : "success"}>{a.status}</StatusPill></div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeader title="Quick Actions" hint="Common admin tasks" />
          <div className="grid grid-cols-2 gap-3">
            {[
              { to: "/admin/wards", icon: Hospital, label: "Add Ward" },
              { to: "/admin/nurses", icon: UserCog, label: "Add Nurse" },
              { to: "/admin/patients", icon: BedDouble, label: "Add Patient" },
              { to: "/admin/reports", icon: FileShortcut, label: "View Reports" },
              { to: "/admin/alerts", icon: AlertTriangle, label: "Manage Alerts" },
              { to: "/admin/settings", icon: Plus, label: "Reset Password" },
            ].map(a => (
              <Link key={a.label} to={a.to}
                className="group flex items-center gap-3 rounded-xl border border-border bg-white p-3 transition hover:border-primary/30 hover:bg-primary-soft/50">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary-soft text-primary">
                  <a.icon className="h-4 w-4" />
                </span>
                <span className="text-sm font-medium text-foreground">{a.label}</span>
              </Link>
            ))}
          </div>

          <div className="mt-6">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Today's hospital summary</div>
            <ul className="mt-2 space-y-2 text-sm">
              {[
                ["Admissions", hospitalSummary.admissions],
                ["Discharges", hospitalSummary.discharges],
                ["Transfers", hospitalSummary.transfers],
                ["Pending assessments", hospitalSummary.pendingAssessments],
                ["Vitals completed", hospitalSummary.vitalsCompleted],
              ].map(([k, v]) => (
                <li key={k as string} className="flex items-center justify-between">
                  <span className="text-muted-foreground">{k}</span>
                  <span className="font-medium text-foreground">{v as number}</span>
                </li>
              ))}
            </ul>
          </div>
        </Card>
      </div>

      {/* Analytics */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <SectionHeader title="Admissions vs Discharges" hint="Last 14 days" />
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={admissionsTrend}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
                <Area type="monotone" dataKey="admissions" stroke="var(--color-primary)" fill="url(#g1)" />
                <Area type="monotone" dataKey="discharges" stroke="var(--color-info)" fill="transparent" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeader title="Alert Trend" hint="Severity breakdown" />
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={alertTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
                <Bar dataKey="red" stackId="s" fill="var(--color-critical)" radius={[4,4,0,0]} />
                <Bar dataKey="orange" stackId="s" fill="var(--color-warning)" />
                <Bar dataKey="yellow" stackId="s" fill="var(--color-info)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeader title="Risk Trend" hint="Composite hospital risk" />
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={alertTrend.map((d,i) => ({ day: d.day, risk: 35 + (d.red*3 + d.orange*1.5 + d.yellow*0.5) + i }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
                <Line type="monotone" dataKey="risk" stroke="var(--color-primary)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <SectionHeader title="Avg Response Time" hint="From alert to nurse action" />
          <div className="grid grid-cols-3 gap-3">
            {[
              { l: "Red", v: "1m 42s", t: "critical" as const },
              { l: "Orange", v: "4m 18s", t: "warning" as const },
              { l: "Yellow", v: "9m 06s", t: "info" as const },
            ].map(s => (
              <div key={s.l} className="rounded-xl border border-border bg-background/60 p-4 text-center">
                <StatusPill tone={s.t}>{s.l}</StatusPill>
                <div className="mt-3 font-display text-2xl text-foreground">{s.v}</div>
                <div className="text-xs text-muted-foreground">median · last 24h</div>
              </div>
            ))}
          </div>
          <div className="mt-5 flex items-center gap-2 rounded-xl bg-primary-soft p-3 text-sm text-foreground ring-1 ring-primary/10">
            <Activity className="h-4 w-4 text-primary" />
            <span>Response times improved 12% over the last week.</span>
          </div>
        </Card>
      </div>
    </div>
  );
}

// Tiny alias to avoid importing a 2nd icon name twice in JSX above.
function FileShortcut(props: { className?: string }) {
  return <Users {...props} />;
}