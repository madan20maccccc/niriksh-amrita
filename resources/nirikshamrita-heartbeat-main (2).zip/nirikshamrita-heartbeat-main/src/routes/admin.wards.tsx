import { createFileRoute } from "@tanstack/react-router";
import { Plus, Pencil, Trash2, Eye, Hospital } from "lucide-react";
import { useState } from "react";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill } from "@/components/ui/status-pill";
import { wards, patients, nurses } from "@/data/hospital";

export const Route = createFileRoute("/admin/wards")({ component: WardsPage });

function WardsPage() {
  const [selected, setSelected] = useState<string | null>(null);
  const ward = selected ? wards.find(w => w.id === selected) : null;

  if (ward) {
    const wp = patients.filter(p => p.ward === ward.name);
    const wn = nurses.filter(n => n.ward === ward.name);
    const tone = ward.riskScore >= 70 ? "critical" : ward.riskScore >= 50 ? "warning" : "success";
    return (
      <div className="space-y-6">
        <button onClick={() => setSelected(null)} className="text-sm text-primary hover:underline">← Back to wards</button>
        <Card className="p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary-soft text-primary"><Hospital className="h-6 w-6" /></span>
              <div>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">{ward.id}</div>
                <h2 className="font-display text-2xl text-foreground">{ward.name}</h2>
              </div>
            </div>
            <StatusPill tone={tone}>{ward.status}</StatusPill>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Mini label="Beds" value={ward.beds} />
            <Mini label="Occupied" value={`${ward.occupied}/${ward.beds}`} />
            <Mini label="Patients" value={ward.patients} />
            <Mini label="Nurses" value={ward.nurses} />
          </div>
        </Card>
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="p-5">
            <SectionHeader title="Assigned Nurses" />
            <ul className="divide-y divide-border">
              {wn.map(n => (
                <li key={n.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="text-sm font-medium text-foreground">{n.name}</div>
                    <div className="text-xs text-muted-foreground">{n.employeeId} · {n.shift} shift</div>
                  </div>
                  <StatusPill tone={n.status === "Active" ? "success" : "muted"}>{n.status}</StatusPill>
                </li>
              ))}
            </ul>
          </Card>
          <Card className="p-5">
            <SectionHeader title="Patients" />
            <ul className="divide-y divide-border">
              {wp.slice(0, 12).map(p => (
                <li key={p.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="text-sm font-medium text-foreground">{p.name}</div>
                    <div className="text-xs text-muted-foreground">{p.bed} · {p.diagnosis}</div>
                  </div>
                  <StatusPill tone={p.risk === "Critical" ? "critical" : p.risk === "High" ? "warning" : p.risk === "Moderate" ? "info" : "success"}>{p.risk}</StatusPill>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <SectionHeader title="Wards" hint="Add, edit and monitor hospital wards" />
        <button className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:opacity-95">
          <Plus className="h-4 w-4" /> Add Ward
        </button>
      </div>
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-5 py-3 text-left">Ward</th>
              <th className="px-5 py-3 text-left">ID</th>
              <th className="px-5 py-3 text-left">Beds</th>
              <th className="px-5 py-3 text-left">Patients</th>
              <th className="px-5 py-3 text-left">Nurses</th>
              <th className="px-5 py-3 text-left">Status</th>
              <th className="px-5 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {wards.map(w => {
              const tone = w.riskScore >= 70 ? "critical" : w.riskScore >= 50 ? "warning" : "success";
              return (
                <tr key={w.id} className="hover:bg-primary-soft/30">
                  <td className="px-5 py-3 font-medium text-foreground">{w.name}</td>
                  <td className="px-5 py-3 text-muted-foreground">{w.id}</td>
                  <td className="px-5 py-3">{w.beds}</td>
                  <td className="px-5 py-3">{w.patients}</td>
                  <td className="px-5 py-3">{w.nurses}</td>
                  <td className="px-5 py-3"><StatusPill tone={tone}>{w.status}</StatusPill></td>
                  <td className="px-5 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <IconBtn onClick={() => setSelected(w.id)}><Eye className="h-4 w-4" /></IconBtn>
                      <IconBtn><Pencil className="h-4 w-4" /></IconBtn>
                      <IconBtn><Trash2 className="h-4 w-4 text-[var(--color-critical)]" /></IconBtn>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-background/60 p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-xl text-foreground">{value}</div>
    </div>
  );
}

function IconBtn({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="grid h-8 w-8 place-items-center rounded-lg border border-border bg-white hover:border-primary/30 hover:bg-primary-soft/50">
      {children}
    </button>
  );
}