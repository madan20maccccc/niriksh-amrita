import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";
import { Logo } from "@/components/brand/Logo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NirikshAmrita — Agentic AI Nursing Safety Platform" },
      { name: "description", content: "Watching every patient. Supporting every nurse. Protecting every life." },
      { property: "og:title", content: "NirikshAmrita" },
      { property: "og:description", content: "Agentic AI nursing safety & patient monitoring platform by Amrita Hospital." },
    ],
  }),
  component: Splash,
});

function Splash() {
  useEffect(() => {
    const t = setTimeout(() => {
      window.location.assign("/welcome");
    }, 2200);
    return () => clearTimeout(t);
  }, []);
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-primary-soft blur-3xl opacity-70" />
        <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-accent blur-3xl opacity-60" />
      </div>
      <div className="relative z-10 flex flex-col items-center gap-6 text-center animate-in fade-in zoom-in-95 duration-700">
        <div className="rounded-full bg-white p-4 shadow-elegant ring-1 ring-primary/15">
          <Logo size={92} />
        </div>
        <div>
          <h1 className="font-display text-4xl text-primary">NirikshAmrita</h1>
          <p className="mt-2 text-sm tracking-wide text-muted-foreground">
            Agentic AI Nursing Safety & Patient Monitoring Platform
          </p>
        </div>
        <div className="mt-4 flex items-center gap-2">
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary" />
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary [animation-delay:150ms]" />
          <span className="h-2 w-2 animate-pulse rounded-full bg-primary [animation-delay:300ms]" />
        </div>
        <p className="text-xs uppercase tracking-[0.24em] text-muted-foreground">
          Amrita Hospital
        </p>
      </div>
    </div>
  );
}
