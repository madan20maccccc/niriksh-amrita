import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import { Card } from "@/components/ui/section";
import { Logo } from "@/components/brand/Logo";
import { patientById } from "@/data/hospital";

export const Route = createFileRoute("/nurse/sbar/$patientId")({ component: SbarPage });

function SbarPage() {
  const { patientId } = useParams({ from: "/nurse/sbar/$patientId" });
  const p = patientById(patientId);
  if (!p) return <div className="text-sm text-muted-foreground">Patient not found.</div>;

  const blocks = [
    { key: "S", t: "Situation",
      body: `${p.name}, ${p.age}${p.gender}, currently in ${p.ward} (Bed ${p.bed}) under ${p.doctor}. Primary issue: ${p.diagnosis}. Current risk level: ${p.risk}.` },
    { key: "B", t: "Background",
      body: `Patient admitted on ${p.admitted}. Known relevant history consistent with primary diagnosis. Recent vitals: BP ${p.vitals.bp}, HR ${p.vitals.hr}, SpO₂ ${p.vitals.spo2}%, Temp ${p.vitals.temp}°F.` },
    { key: "A", t: "Assessment",
      body: p.aiSummary },
    { key: "R", t: "Recommendation",
      body: p.risk === "Critical"
        ? "Recommend urgent clinical review by on-call physician, oxygen titration, and continuous monitoring."
        : p.risk === "High"
        ? "Recommend re-assessment within 2 hours, fluid balance check and informing the on-call physician if vitals deteriorate."
        : "Continue current care plan, routine monitoring, and inform if any new symptom appears." },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link to={`/nurse/patient/${p.id}` as never} className="text-sm text-primary hover:underline">← Back to {p.name}</Link>
        <button onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-sm"><Printer className="h-4 w-4" /> Print / PDF</button>
      </div>
      <Card className="p-8">
        <div className="flex items-center justify-between border-b border-border pb-4">
          <Logo size={40} withWordmark tone="compact" />
          <div className="text-right text-xs text-muted-foreground">
            <div>SBAR Handover Note</div>
            <div className="font-medium text-foreground">{new Date().toLocaleString()}</div>
          </div>
        </div>
        <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
          <KV k="Patient" v={`${p.name} (${p.id})`} />
          <KV k="Age / Sex" v={`${p.age} · ${p.gender === "M" ? "Male" : "Female"}`} />
          <KV k="Ward / Bed" v={`${p.ward} · ${p.bed}`} />
          <KV k="Doctor" v={p.doctor} />
        </div>
        <div className="mt-6 space-y-4">
          {blocks.map(b => (
            <div key={b.key} className="rounded-2xl border border-border bg-background/60 p-5">
              <div className="flex items-center gap-3">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-lg font-semibold text-primary-foreground">{b.key}</div>
                <div className="font-display text-lg text-foreground">{b.t}</div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-foreground">{b.body}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className="font-medium text-foreground">{v}</div>
    </div>
  );
}