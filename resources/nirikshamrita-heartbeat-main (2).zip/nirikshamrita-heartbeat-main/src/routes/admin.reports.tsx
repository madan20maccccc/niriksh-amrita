import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Download, FileSpreadsheet, FileText } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, SectionHeader } from "@/components/ui/section";
import { admissionsTrend, alertTrend, hospitalSummary } from "@/data/hospital";

export const Route = createFileRoute("/admin/reports")({ component: ReportsPage });

function ReportsPage() {
  const [range, setRange] = useState<"Daily" | "Weekly" | "Monthly">("Weekly");
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SectionHeader title="Reports" hint="Operational reports and exports" />
        <div className="flex items-center gap-2">
          {(["Daily","Weekly","Monthly"] as const).map(r => (
            <button key={r} onClick={() => setRange(r)}
              className={"rounded-xl px-3 py-2 text-sm " + (range === r ? "bg-primary text-primary-foreground shadow-elegant" : "border border-border bg-white text-foreground")}>
              {r}
            </button>
          ))}
          <button className="inline-flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-sm"><FileText className="h-4 w-4" /> Export PDF</button>
          <button className="inline-flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-sm"><FileSpreadsheet className="h-4 w-4" /> Export Excel</button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        {[
          ["Admissions", hospitalSummary.admissions],
          ["Discharges", hospitalSummary.discharges],
          ["Transfers", hospitalSummary.transfers],
          ["Vitals completed", hospitalSummary.vitalsCompleted],
        ].map(([l, v]) => (
          <Card key={l as string} className="p-5">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{l}</div>
            <div className="mt-2 font-display text-3xl text-foreground">{v as number}</div>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <SectionHeader title="Admissions" hint={`${range} view`} />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={admissionsTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
                <Bar dataKey="admissions" fill="var(--color-primary)" radius={[6,6,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-5">
          <SectionHeader title="Alert pattern" hint="Severity over time" />
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={alertTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="day" stroke="var(--color-muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--color-muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
                <Line type="monotone" dataKey="red" stroke="var(--color-critical)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="orange" stroke="var(--color-warning)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="yellow" stroke="var(--color-info)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <SectionHeader title="Download archive" hint="Recent generated reports" />
        <ul className="divide-y divide-border">
          {["Weekly clinical safety summary","ICU oxygen support report","Nurse coverage report","Monthly admissions overview"].map(t => (
            <li key={t} className="flex items-center justify-between py-3">
              <div className="flex items-center gap-3">
                <div className="grid h-9 w-9 place-items-center rounded-xl bg-primary-soft text-primary"><FileText className="h-4 w-4" /></div>
                <div>
                  <div className="text-sm font-medium text-foreground">{t}</div>
                  <div className="text-xs text-muted-foreground">Generated today · 1.2 MB</div>
                </div>
              </div>
              <button className="inline-flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-sm"><Download className="h-4 w-4" /> Download</button>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}