import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Search, Pencil, Trash2, KeyRound, Filter } from "lucide-react";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill } from "@/components/ui/status-pill";
import { nurses, wards } from "@/data/hospital";

export const Route = createFileRoute("/admin/nurses")({ component: NursesPage });

function NursesPage() {
  const [q, setQ] = useState("");
  const [ward, setWard] = useState<string>("All");
  const [showAdd, setShowAdd] = useState(false);
  const filtered = nurses.filter(n =>
    (ward === "All" || n.ward === ward) &&
    (n.name.toLowerCase().includes(q.toLowerCase()) || n.employeeId.toLowerCase().includes(q.toLowerCase())));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SectionHeader title="Nursing Staff" hint={`${nurses.length} nurses across ${wards.length} wards`} />
        <button onClick={() => setShowAdd(true)} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:opacity-95">
          <Plus className="h-4 w-4" /> Add Nurse
        </button>
      </div>

      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex flex-1 items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by name or employee ID" className="w-full bg-transparent outline-none" />
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <select value={ward} onChange={e => setWard(e.target.value)} className="bg-transparent outline-none">
              <option>All</option>
              {wards.map(w => <option key={w.id}>{w.name}</option>)}
            </select>
          </div>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-5 py-3 text-left">Name</th>
              <th className="px-5 py-3 text-left">Employee ID</th>
              <th className="px-5 py-3 text-left">Contact</th>
              <th className="px-5 py-3 text-left">Shift</th>
              <th className="px-5 py-3 text-left">Ward</th>
              <th className="px-5 py-3 text-left">Status</th>
              <th className="px-5 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map(n => (
              <tr key={n.id} className="hover:bg-primary-soft/30">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className="grid h-9 w-9 place-items-center rounded-full bg-primary-soft font-medium text-primary">{n.name[0]}</div>
                    <div className="font-medium text-foreground">{n.name}</div>
                  </div>
                </td>
                <td className="px-5 py-3 text-muted-foreground">{n.employeeId}</td>
                <td className="px-5 py-3 text-muted-foreground">
                  <div>{n.email}</div>
                  <div className="text-xs">{n.phone}</div>
                </td>
                <td className="px-5 py-3">{n.shift}</td>
                <td className="px-5 py-3">{n.ward}</td>
                <td className="px-5 py-3"><StatusPill tone={n.status === "Active" ? "success" : "muted"}>{n.status}</StatusPill></td>
                <td className="px-5 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <IconBtn><KeyRound className="h-4 w-4" /></IconBtn>
                    <IconBtn><Pencil className="h-4 w-4" /></IconBtn>
                    <IconBtn><Trash2 className="h-4 w-4 text-[var(--color-critical)]" /></IconBtn>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {showAdd && <AddNurseModal onClose={() => setShowAdd(false)} />}
    </div>
  );
}

function IconBtn({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} className="grid h-8 w-8 place-items-center rounded-lg border border-border bg-white hover:border-primary/30 hover:bg-primary-soft/50">
      {children}
    </button>
  );
}

function AddNurseModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4">
      <div className="w-full max-w-lg rounded-2xl border border-border bg-card p-6 shadow-elegant">
        <h3 className="font-display text-xl text-foreground">Add Nurse</h3>
        <p className="text-sm text-muted-foreground">Create a new nursing staff record.</p>
        <form className="mt-5 grid gap-4 sm:grid-cols-2" onSubmit={e => { e.preventDefault(); onClose(); }}>
          <Field label="Full name" />
          <Field label="Employee ID" />
          <Field label="Email" type="email" />
          <Field label="Phone" />
          <Field label="Password" type="password" />
          <SelectField label="Shift" options={["Morning","Evening","Night"]} />
          <SelectField label="Assigned ward" options={wards.map(w => w.name)} className="sm:col-span-2" />
          <div className="sm:col-span-2 mt-2 flex justify-end gap-2">
            <button type="button" onClick={onClose} className="rounded-xl border border-border bg-white px-4 py-2.5 text-sm">Cancel</button>
            <button type="submit" className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant">Create nurse</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, type = "text" }: { label: string; type?: string }) {
  return (
    <label className="block text-sm">
      <span className="font-medium text-foreground">{label}</span>
      <input type={type} className="mt-1.5 w-full rounded-xl border border-input bg-white px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary/30" />
    </label>
  );
}
function SelectField({ label, options, className }: { label: string; options: string[]; className?: string }) {
  return (
    <label className={"block text-sm " + (className ?? "")}>
      <span className="font-medium text-foreground">{label}</span>
      <select className="mt-1.5 w-full rounded-xl border border-input bg-white px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary/30">
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </label>
  );
}