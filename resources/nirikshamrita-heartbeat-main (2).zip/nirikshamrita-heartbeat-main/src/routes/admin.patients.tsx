import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Plus, Search, Filter, Pencil, Trash2, ArrowLeftRight } from "lucide-react";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill, riskTone } from "@/components/ui/status-pill";
import { patients, wards } from "@/data/hospital";

export const Route = createFileRoute("/admin/patients")({ component: PatientsPage });

function PatientsPage() {
  const [q, setQ] = useState("");
  const [ward, setWard] = useState("All");
  const filtered = patients.filter(p =>
    (ward === "All" || p.ward === ward) &&
    (p.name.toLowerCase().includes(q.toLowerCase()) || p.id.toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <SectionHeader title="Patients" hint={`${patients.length} active patients`} />
        <button className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant hover:opacity-95">
          <Plus className="h-4 w-4" /> Add Patient
        </button>
      </div>
      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex flex-1 items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm">
            <Search className="h-4 w-4 text-muted-foreground" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by name or patient ID" className="w-full bg-transparent outline-none" />
          </div>
          <div className="flex items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <select value={ward} onChange={e => setWard(e.target.value)} className="bg-transparent outline-none">
              <option>All</option>
              {wards.map(w => <option key={w.id}>{w.name}</option>)}
            </select>
          </div>
        </div>
      </Card>
      <Card className="overflow-hidden">
        <div className="max-h-[60vh] overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-muted/70 backdrop-blur text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-5 py-3 text-left">Patient</th>
                <th className="px-5 py-3 text-left">ID</th>
                <th className="px-5 py-3 text-left">Age/Sex</th>
                <th className="px-5 py-3 text-left">Diagnosis</th>
                <th className="px-5 py-3 text-left">Ward / Bed</th>
                <th className="px-5 py-3 text-left">Doctor</th>
                <th className="px-5 py-3 text-left">Risk</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.slice(0, 80).map(p => (
                <tr key={p.id} className="hover:bg-primary-soft/30">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="grid h-9 w-9 place-items-center rounded-full bg-primary-soft text-sm font-medium text-primary">{p.name[0]}</div>
                      <div className="font-medium text-foreground">{p.name}</div>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-muted-foreground">{p.id}</td>
                  <td className="px-5 py-3">{p.age} · {p.gender}</td>
                  <td className="px-5 py-3 max-w-[14rem] truncate">{p.diagnosis}</td>
                  <td className="px-5 py-3">{p.ward} · {p.bed}</td>
                  <td className="px-5 py-3">{p.doctor}</td>
                  <td className="px-5 py-3"><StatusPill tone={riskTone(p.risk)}>{p.risk}</StatusPill></td>
                  <td className="px-5 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <Btn><ArrowLeftRight className="h-4 w-4" /></Btn>
                      <Btn><Pencil className="h-4 w-4" /></Btn>
                      <Btn><Trash2 className="h-4 w-4 text-[var(--color-critical)]" /></Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function Btn({ children }: { children: React.ReactNode }) {
  return (
    <button className="grid h-8 w-8 place-items-center rounded-lg border border-border bg-white hover:border-primary/30 hover:bg-primary-soft/50">
      {children}
    </button>
  );
}