import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { Card, SectionHeader } from "@/components/ui/section";
import { StatusPill, riskTone } from "@/components/ui/status-pill";
import { getSession } from "@/lib/auth";
import { nurses, patientsForNurse } from "@/data/hospital";

export const Route = createFileRoute("/nurse/patients")({ component: NursePatients });

function NursePatients() {
  const [nurseId, setNurseId] = useState(nurses[0].id);
  const [q, setQ] = useState("");
  useEffect(() => {
    const s = getSession();
    const n = nurses.find(n => n.email === s?.email) ?? nurses[0];
    setNurseId(n.id);
  }, []);
  const myPatients = patientsForNurse(nurseId).filter(p =>
    p.name.toLowerCase().includes(q.toLowerCase()) || p.bed.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-6">
      <SectionHeader title="My Patients" hint={`${myPatients.length} patients in your ward this shift`} />
      <Card className="p-4">
        <div className="flex items-center gap-2 rounded-xl border border-input bg-white px-3 py-2 text-sm">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by name or bed" className="w-full bg-transparent outline-none" />
        </div>
      </Card>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {myPatients.map(p => (
          <Card key={p.id} className="p-5 transition hover:shadow-elegant">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-primary-soft font-medium text-primary">{p.name[0]}</div>
                <div>
                  <div className="font-medium text-foreground">{p.name}</div>
                  <div className="text-xs text-muted-foreground">Bed {p.bed} · {p.age}{p.gender}</div>
                </div>
              </div>
              <StatusPill tone={riskTone(p.risk)}>{p.risk}</StatusPill>
            </div>
            <div className="mt-3 text-xs text-muted-foreground">{p.diagnosis}</div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              <Vital l="BP" v={p.vitals.bp} />
              <Vital l="HR" v={String(p.vitals.hr)} />
              <Vital l="SpO₂" v={`${p.vitals.spo2}%`} />
            </div>
            <div className="mt-4 flex items-center gap-2">
              <Link to={`/nurse/patient/${p.id}` as never} className="flex-1 rounded-xl bg-primary px-3 py-2 text-center text-sm font-semibold text-primary-foreground shadow-elegant">View details</Link>
              <Link to={`/nurse/vitals/${p.id}` as never} className="rounded-xl border border-border bg-white px-3 py-2 text-sm">Enter vitals</Link>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function Vital({ l, v }: { l: string; v: string }) {
  return (
    <div className="rounded-lg border border-border bg-background/60 py-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{l}</div>
      <div className="text-sm font-medium text-foreground">{v}</div>
    </div>
  );
}