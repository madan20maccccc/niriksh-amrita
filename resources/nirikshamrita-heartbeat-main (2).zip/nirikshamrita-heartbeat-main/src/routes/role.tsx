import { createFileRoute, Link } from "@tanstack/react-router";
import { Shield, Stethoscope, ChevronRight } from "lucide-react";
import { Logo } from "@/components/brand/Logo";

export const Route = createFileRoute("/role")({
  head: () => ({
    meta: [
      { title: "Choose your role — NirikshAmrita" },
      { name: "description", content: "Sign in as Administrator or Nurse." },
    ],
  }),
  component: RolePage,
});

function RolePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-primary-soft/40">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <Link to="/welcome"><Logo size={36} withWordmark tone="compact" /></Link>
        <Link to="/welcome" className="text-sm text-muted-foreground hover:text-foreground">← Back</Link>
      </div>
      <div className="mx-auto max-w-5xl px-6 py-12">
        <div className="text-center">
          <h1 className="font-display text-4xl text-foreground">Who's signing in?</h1>
          <p className="mt-3 text-muted-foreground">
            NirikshAmrita is used by hospital administrators and bedside nursing teams.
          </p>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {[
            { to: "/login/admin", icon: Shield, title: "Administrator", body: "Hospital command center, ward management, nurse and patient administration, reports and alerts oversight." },
            { to: "/login/nurse", icon: Stethoscope, title: "Nurse", body: "Ward-level workflow: my patients, vitals entry, AI summaries, SBAR handover and shift tasks." },
          ].map(c => (
            <Link
              key={c.to}
              to={c.to}
              className="group relative overflow-hidden rounded-3xl border border-border bg-white p-8 shadow-card transition hover:shadow-elegant"
            >
              <div className="absolute inset-x-0 top-0 h-1 gradient-primary" />
              <div className="flex items-center justify-between">
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-primary-soft text-primary">
                  <c.icon className="h-7 w-7" />
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" />
              </div>
              <h2 className="mt-6 font-display text-2xl text-foreground">{c.title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{c.body}</p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}