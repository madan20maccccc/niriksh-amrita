import { createFileRoute, Link, useNavigate, useParams } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { Card, SectionHeader } from "@/components/ui/section";
import { patientById } from "@/data/hospital";

export const Route = createFileRoute("/nurse/vitals/$patientId")({ component: VitalsPage });

function VitalsPage() {
  const { patientId } = useParams({ from: "/nurse/vitals/$patientId" });
  const navigate = useNavigate();
  const p = patientById(patientId);
  const [time, setTime] = useState<"Morning" | "Evening" | "Night">("Morning");
  const [done, setDone] = useState(false);
  const [action, setAction] = useState<string | null>(null);
  if (!p) return <div className="text-sm text-muted-foreground">Patient not found.</div>;

  return (
    <div className="space-y-6">
      <Link to={`/nurse/patient/${p.id}` as never} className="text-sm text-primary hover:underline">← Back to {p.name}</Link>

      <Card className="p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <SectionHeader title={`Record vitals — ${p.name}`} hint={`${p.ward} · Bed ${p.bed} · ${p.diagnosis}`} />
          <div className="flex items-center gap-2">
            {(["Morning","Evening","Night"] as const).map(t => (
              <button key={t} onClick={() => setTime(t)}
                className={"rounded-xl px-3 py-2 text-sm " + (time === t ? "bg-primary text-primary-foreground shadow-elegant" : "border border-border bg-white text-foreground")}>
                {t}
              </button>
            ))}
          </div>
        </div>
        <form onSubmit={e => { e.preventDefault(); setDone(true); }} className="mt-4 grid gap-4 md:grid-cols-3">
          <Field label="Blood pressure" placeholder="e.g. 124/82" />
          <Field label="Heart rate (bpm)" placeholder="e.g. 88" />
          <Field label="Sugar (mg/dL)" placeholder="e.g. 142" />
          <Field label="Temperature (°F)" placeholder="e.g. 98.6" />
          <Field label="SpO₂ (%)" placeholder="e.g. 97" />
          <Field label="Respiratory rate (/min)" placeholder="e.g. 18" />
          <Field label="Pain score (0-10)" placeholder="e.g. 3" />
          <Field label="Urine output (ml)" placeholder="e.g. 800" />
          <SelectField label="Consciousness" options={["Alert","Drowsy","Confused","Unresponsive"]} />
          <label className="md:col-span-3 block text-sm">
            <span className="font-medium text-foreground">Remarks</span>
            <textarea rows={3} className="mt-1.5 w-full rounded-xl border border-input bg-white px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary/30" placeholder="Optional clinical note" />
          </label>
          <div className="md:col-span-3 flex justify-end gap-2">
            <Link to={`/nurse/patient/${p.id}` as never} className="rounded-xl border border-border bg-white px-4 py-2.5 text-sm">Cancel</Link>
            <button type="submit" className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant">Save vitals</button>
          </div>
        </form>
      </Card>

      <Card className="p-5">
        <SectionHeader title="Nurse Action" hint="Log clinical actions taken" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {["Rechecked Vitals","Doctor Informed","Medicine Given","Oxygen Started","Sample Sent","Patient Shifted","False Alert","Patient Refused","Other Notes"].map(a => (
            <button key={a} onClick={() => setAction(a)}
              className={"rounded-xl border px-3 py-3 text-sm transition " +
                (action === a ? "border-primary bg-primary-soft text-primary" : "border-border bg-white hover:border-primary/30")}>
              {a}
            </button>
          ))}
        </div>
      </Card>

      {done && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 text-center shadow-elegant">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-[color-mix(in_oklab,var(--color-success)_15%,transparent)] text-[var(--color-success)]">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h3 className="mt-4 font-display text-xl text-foreground">Vitals recorded</h3>
            <p className="mt-1 text-sm text-muted-foreground">{time} round for {p.name} saved successfully.</p>
            <div className="mt-5 flex justify-center gap-2">
              <button onClick={() => setDone(false)} className="rounded-xl border border-border bg-white px-4 py-2.5 text-sm">Add another</button>
              <button onClick={() => navigate({ to: `/nurse/patient/${p.id}` as never })} className="rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-elegant">Back to patient</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, placeholder }: { label: string; placeholder?: string }) {
  return (
    <label className="block text-sm">
      <span className="font-medium text-foreground">{label}</span>
      <input placeholder={placeholder} className="mt-1.5 w-full rounded-xl border border-input bg-white px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary/30" />
    </label>
  );
}
function SelectField({ label, options }: { label: string; options: string[] }) {
  return (
    <label className="block text-sm">
      <span className="font-medium text-foreground">{label}</span>
      <select className="mt-1.5 w-full rounded-xl border border-input bg-white px-3 py-2.5 outline-none focus:ring-2 focus:ring-primary/30">
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </label>
  );
}